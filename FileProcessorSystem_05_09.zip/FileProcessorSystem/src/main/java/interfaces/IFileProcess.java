package interfaces;

public interface IFileProcess {
  
  public void processFile();
  
}
