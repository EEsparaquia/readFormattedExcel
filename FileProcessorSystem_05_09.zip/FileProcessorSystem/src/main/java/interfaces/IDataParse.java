package interfaces;

public interface IDataParse {

  public Object read(Object jsonData);

  public void write();
}
