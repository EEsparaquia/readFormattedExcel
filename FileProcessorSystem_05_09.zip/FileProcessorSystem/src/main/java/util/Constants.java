package util;

public class Constants {
  
  public static final String EMPTY = "";
  public static final int COL_PARAM_ROW_INDEX = 6;
  public static final String INPUT_FILE_PATH = "src/main/resources/contentSpreadsheet.xlsx";
  public static final String OUTPUT_FILE_PATH = "Order.json";
  
}
