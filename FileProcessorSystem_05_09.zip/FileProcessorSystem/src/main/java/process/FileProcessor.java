package process;

/**
 * Any generic implementation common to different file types can be kept here.
 */
public abstract class FileProcessor {

  public String filePath;

  public FileProcessor(String filePath) {
    this.filePath = filePath;
  }
}
