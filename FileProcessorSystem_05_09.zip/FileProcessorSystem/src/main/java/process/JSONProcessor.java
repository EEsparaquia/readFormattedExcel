package process;

import java.io.FileWriter;
import java.io.Writer;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import interfaces.IDataParse;
import model.OrderDetails;

public class JSONProcessor implements IDataParse {

  Object inputObject;
  String filePath;

  public JSONProcessor(Object object, String path) {
    this.inputObject = object;
    this.filePath = path;
  }

  @Override
  public Object read(Object jsonData) {
    return null;
  }

  @Override
  /**
   * Method used to convert the data objects to JSON and save to a location
   * 
   */
  public void write() {

    OrderDetails orderDetails = (OrderDetails) inputObject;

    try (Writer writer = new FileWriter(filePath)) {
      Gson gson = new GsonBuilder().setPrettyPrinting().create();
      gson.toJson(orderDetails, writer);
    } catch (Exception e) {
      System.out.println("Exception in write: " + e);
    }
  }
}
