package process;

import org.apache.poi.ss.usermodel.Cell;
import model.Parameters;

/**
 * This class is used to read an excel and convert all it's data fields to a JSON file; Only columns
 * of type text will be parsed and added to JSON
 */
public class ExcelNumericFileProcessor extends AbstractExcelFileProcessor {

  public ExcelNumericFileProcessor(String filePath) {
    super(filePath, "Numeric");
  }

  /**
   * If the current column data type is float, process it; if the cell returns an string, convert it
   * to float
   * 
   * @param cell
   * @param cellIndex
   * @param param
   */
  @Override
  Parameters buildParams(Cell cell, int cellIndex) {

    String predefinedColType = columnTypeMap.get(columnTypeMap.floorKey(cellIndex));

    Parameters param = null;

    if ("Float".equalsIgnoreCase(predefinedColType)) {

      param = new Parameters();
      param.setParameterName(columnHeaderMap.get(cellIndex));
      param.setDataType(predefinedColType);

      switch (cell.getCellType()) {
        case Cell.CELL_TYPE_BLANK:
          break;

        case Cell.CELL_TYPE_NUMERIC:
          param.setValue(String.valueOf(cell.getNumericCellValue()));
          break;

        case Cell.CELL_TYPE_STRING:
          param.setValue(cell.getStringCellValue());
          break;
      }
    }
    return param;
  }
}
