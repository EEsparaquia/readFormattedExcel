package process;

import static util.Constants.EMPTY;
import static util.Constants.HEADER_ROW_INDEX;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.ResourceBundle;
import java.util.TreeMap;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import interfaces.IFileProcessor;
import model.MergeCellRange;
import model.Order;
import model.OrderDetails;
import model.Parameters;

/**
 * Parent class for excel file processor; performs the common functionalities
 */
public abstract class AbstractExcelFileProcessor implements IFileProcessor {

  String filePath;
  String fileProcessingType;

  Map<Integer, List<MergeCellRange>> mergeCellMap = new HashMap<>();
  Map<Integer, String> columnHeaderMap = new HashMap<>();

  static ResourceBundle commonProperties = ResourceBundle.getBundle("properties.fileProcessor");

  static NavigableMap<Integer, String> columnTypeMap = null; // map is used to identify the column
                                                             // types of each parameter
  static {
    columnTypeMap = new TreeMap<Integer, String>();
    columnTypeMap.put(0, "String");
    columnTypeMap.put(1, "Timestamp"); // 1 TimeStamp
    columnTypeMap.put(2, "String"); // 2-66 String
    columnTypeMap.put(66, "String"); // 66 String
    columnTypeMap.put(67, "Float"); // 67-88 String
    columnTypeMap.put(89, "String"); // 89-90 String
    columnTypeMap.put(113, "String"); // 114....
  }

  public AbstractExcelFileProcessor(String filePath, String fileProcessingType) {
    this.filePath = filePath;
    this.fileProcessingType = fileProcessingType;
  }

  /**
   * Method used to parse the excel and builds the object required to convert to JSON
   */
  public void processFile() {

    OrderDetails orderDetails = new OrderDetails();
    List<Order> orderList = new ArrayList<>();

    try (FileInputStream inputFile = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(inputFile);) {

      Sheet sheet = workbook.getSheetAt(0); // assume only one sheet available

      populateMergeCellRegionMap(sheet); // This method will determine the parent headers(level - by
                                         // - level)

      populateColumnHeaderMap(sheet); // This map builds the actual column header value

      orderDetails.setOrderName(sheet.getRow(0).getCell(0).getStringCellValue());
      orderDetails.setModelNumber(sheet.getRow(1).getCell(0).getStringCellValue());
      orderDetails.setProcessingType(fileProcessingType);

      Iterator<Row> rowIterator = sheet.iterator();

      String block = EMPTY;
      String subBlock = EMPTY;

      while (rowIterator.hasNext()) {

        Row row = rowIterator.next();
        int rowNum = row.getRowNum();
        System.out.println("Processing row: " + rowNum);

        if (rowNum >= 9) { // Actual data starts from row >= 9
          if (row.getCell(0).getCellType() == Cell.CELL_TYPE_BLANK) { // To stop processing blank
                                                                      // rows after data rows are
                                                                      // parsed.
            break;
          }

          Order order = new Order();

          Iterator<Cell> cellIterator = row.cellIterator();
          List<Parameters> paramList = new ArrayList<>();

          while (cellIterator.hasNext()) {

            Cell cell = cellIterator.next();
            int colIndex = cell.getColumnIndex();

            if (colIndex == 0) {
              // For order number, block, and sub block
              switch (cell.getCellType()) {
                case Cell.CELL_TYPE_NUMERIC:
                  order.setOrderNum(String.valueOf((int) cell.getNumericCellValue()));
                  break;

                case Cell.CELL_TYPE_STRING:
                  if ("H1".equals(cell.getStringCellValue()))
                    block = row.getCell(1).getStringCellValue();
                  else if ("H2".equals(cell.getStringCellValue()))
                    subBlock = row.getCell(1).getStringCellValue();
                  break;
              }
              continue;
            }

            Parameters param = buildParams(cell, colIndex);

            if (param != null) {
              param.setBlock(block);
              param.setSubBlock(subBlock);
              paramList.add(param);
            }
          }
          order.setParameters(paramList);
          orderList.add(order);
        }
      }

      orderDetails.setOrder(orderList);

      // Writes the object to a JSON file
      new JSONProcessor(orderDetails, orderDetails.getOrderName().concat("_")
          .concat(orderDetails.getProcessingType()).concat(".json")).write();

    } catch (Exception e) {
      System.out.println("Exception in processFile: " + e);
    }
  }

  abstract Parameters buildParams(Cell cell, int cellIndex);

  /**
   * Method used to determine the merged cell range which helps us to build the parameter header
   * 
   * @param sheet
   */
  public void populateMergeCellRegionMap(Sheet sheet) {

    try {
      for (int i = 0; i < sheet.getNumMergedRegions(); i++) {
        CellRangeAddress region = sheet.getMergedRegion(i);

        int colStart = region.getFirstColumn();
        int colEnd = region.getLastColumn();
        int rowNum = region.getFirstRow();

        if (sheet.getRow(rowNum).getCell(colStart).getCellType() == Cell.CELL_TYPE_BLANK
            || sheet.getRow(rowNum).getCell(colStart) == null) {
          continue;
        }

        if (rowNum < 2)
          continue; // First two rows takes the order name & model number

        if (rowNum > 5)
          return; // The parent header available till row 5. TODO what if getNumMergeRegions is not
                  // sorted. like 7, and then 4. will you return?

        MergeCellRange range = new MergeCellRange(colStart, colEnd,
            sheet.getRow(rowNum).getCell(colStart).getStringCellValue());

        if (mergeCellMap.containsKey(rowNum)) {
          mergeCellMap.get(rowNum).add(range);
        } else {
          List<MergeCellRange> list = new ArrayList<>();
          list.add(range);
          mergeCellMap.put(rowNum, list);
        }
      }
    } catch (Exception e) {
      System.out.println("Exception in populateMergeCellRegionMap: " + e);
    }
  }

  /**
   * Method used to concatenate the parameter header with it's parent(Hierarchical)
   * 
   * @param sheet
   */
  public void populateColumnHeaderMap(Sheet sheet) {

    try {
      int row = Integer.parseInt(commonProperties.getString(HEADER_ROW_INDEX)); // Predetermined
                                                                                // header row
      Row headerRow = sheet.getRow(row);
      Iterator<Cell> cellIterator = headerRow.cellIterator();

      while (cellIterator.hasNext()) {
        Cell cell = cellIterator.next();
        int colIndex = cell.getColumnIndex();

        String header = getParentLabelName(sheet, headerRow, cell);

        Cell nextCell = sheet.getRow(row + 1).getCell(colIndex);
        String next = EMPTY;

        switch (nextCell.getCellType()) {
          case Cell.CELL_TYPE_NUMERIC:
            next = String.valueOf((int) nextCell.getNumericCellValue());
            break;
          case Cell.CELL_TYPE_STRING:
            next = nextCell.getStringCellValue();
            break;
        }
        if (!EMPTY.equalsIgnoreCase(next)) {
          if (headerRow.getCell(colIndex).getCellType() == Cell.CELL_TYPE_BLANK)
            header = header.concat(" : ").concat(next);
          else
            header = header.concat(" ").concat(next);
        }

        columnHeaderMap.put(colIndex, header);
      }
    } catch (Exception e) {
      System.out.println("Exception in populateColumnHeaderMap: " + e);
    }
  }

  /**
   * Recursively go to the top hierarchy and check any label available for this cell(within this
   * index or within the merged range(if any)), append the parent label with the current parameter
   */
  public String getParentLabelName(Sheet sheet, Row row, Cell col) {
    return getParentLabelName(sheet, row.getRowNum(), col.getColumnIndex());
  }

  public String getParentLabelName(Sheet sheet, int currentRow, int currentCol) {

    if (currentRow < 2)
      return EMPTY;

    String temp = EMPTY;

    try {
      temp = getParentLabelName(sheet, currentRow - 1, currentCol);

      Row row = sheet.getRow(currentRow);
      // System.out.println("Row Number: " + row.getRowNum());

      Cell cell = row.getCell(currentCol);
      String cellValue = EMPTY;

      switch (cell.getCellType()) {
        case Cell.CELL_TYPE_NUMERIC:
          cellValue = String.valueOf(cell.getNumericCellValue());
          break;
        case Cell.CELL_TYPE_STRING:
          cellValue = cell.getStringCellValue();
          break;
      }

      if (!EMPTY.equals(cellValue)) {
        if (EMPTY.equals(temp)) {
          temp = cellValue;
        } else {
          temp = temp.concat(" : ").concat(cellValue);
        }
      }
      // Means either it's empty or it's in the mid of merged cell range.
      else {
        String str = getCellValue(currentRow, currentCol);
        if (!EMPTY.equals(str)) {
          if (EMPTY.equals(temp)) {
            temp = str;
          } else {
            temp = temp.concat(" : ").concat(str);
          }
        }
      }
    } catch (Exception e) {
      System.out.println("Exception in getParentLabelName: " + e);
    }
    return temp;
  }

  /**
   * Method finds whether the given cell has any parent header value
   * 
   * @param row
   * @param cell
   * @return
   */
  public String getCellValue(int row, int cell) {

    String result = EMPTY;
    try {
      if (row > 0 && mergeCellMap.containsKey(row)) {
        List<MergeCellRange> list = (List<MergeCellRange>) mergeCellMap.get(row);
        Collections.sort(list);
        result = findValueInRange(list, cell, 0, list.size() - 1);
      }
    } catch (Exception e) {
      System.out.println("Exception in getCellValue: " + e);
    }
    return result;
  }

  /**
   * Binary search whether the current cell falls in between the parent header
   * 
   * @param list
   * @param cell
   * @param start
   * @param end
   * @return
   */
  public String findValueInRange(List<MergeCellRange> list, int cell, int start, int end) {

    if (start > end)
      return EMPTY;

    int mid = start + (end - start) / 2;
    MergeCellRange range = list.get(mid);

    if (cell >= range.getCellStart() && cell <= range.getCellEnd())
      return range.getLabel();
    if (cell < range.getCellStart())
      return findValueInRange(list, cell, start, end - 1);
    else
      return findValueInRange(list, cell, start + 1, end);
  }

}
