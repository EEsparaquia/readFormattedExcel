package main;

import static util.Constants.INPUT_FILE_PATH;
import interfaces.IFileProcessor;
import process.ExcelNumericFileProcessor;
import process.ExcelTextFileProcessor;

/**
 * This is the main class for processing this excel to JSON; Pass the input file path as argument
 */
public class ProcessExcelToJSONBatch {

  public static void main(String[] args) {

    // String filePath = (String)args[0];
    String filePath = INPUT_FILE_PATH;

    IFileProcessor textProcessor = new ExcelTextFileProcessor(filePath);
    textProcessor.processFile();

    IFileProcessor numericProcessor = new ExcelNumericFileProcessor(filePath);
    numericProcessor.processFile();
  }
}
