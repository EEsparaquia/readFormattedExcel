package interfaces;

public interface IFileProcessor {

  void processFile();
}
