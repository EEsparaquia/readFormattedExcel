package util;

public class Constants {
  
  public static final String EMPTY = "";
  public static final String HEADER_ROW_INDEX = "header.row.index";
  public static final String INPUT_FILE_PATH = "src/main/resources/excelfiles/contentSpreadsheet.xlsx";
  
}
