package util;

public class Constants {
  
  public static final String EMPTY = "";
  public static final String EXCEL_FILE_NAME = "contentSpreadsheet";
  public static final int COL_PARAM_ROW_INDEX = 6;
  public static final String JSON_OUTPUT_FILE = "C:\\Output\\order.json";
  
}
